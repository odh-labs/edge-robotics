# robots > 2023-02-13 1:00pm
https://universe.roboflow.com/object-detection/robots-fy7na

Provided by a Roboflow user
License: CC BY 4.0

